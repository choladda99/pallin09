<!DOCTYPE html>
<html lang="en">
<head>
  <title>Green world tour</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #56d343;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="Index.php">หน้าแรก</a></li>
        <li><a href="4.php">เกร็ดความรู้</a></li>
        <li><a href="3.php">สินค้าสีเขียว</a></li>
        <li><a href="2.php">มุมสีเขียว</a></li>
		<li><a href="show.php">การจัดการข้อมูล</a></li>
      </ul>

    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
    </div>
    <div class="col-sm-8 text-left"> 
      <h1>มาดูมุมสีเขียว มุมธรรมชาติกันเถอะ!!</h1>
      <hr>
      <h3>มุมฝาผนัง</h3>
      <center><img src="https://cdn.trendhunterstatic.com/thumbs/cork-planters.jpeg" width="40%" border="0" /></center><br>
      <p>การใส่ใจรายละเอียดในการตกแต่งบ้าน ไม่ว่าจะเป็นเรื่องเล็กน้อย ละเอียดอ่อนแค่ไหน ล้วนแล้วแต่มีส่วนทำให้บ้านดูดีขึ้นมาได้ทั้งนั้น 
        เรื่องตกแต่งมุมฝาผนังก็เช่นกัน ที่หลายคนให้ความสำคัญไม่น้อย พิถีพิถันตั้งแต่การเลือกชนิดของพืชพรรณ รูปร่าง ไปจนถึงการจัดองค์ประกอบ
        ไม่ใช่แค่ทำให้บ้านดูดี แต่ในเมื่อบ้านมีสวนสวยๆ มีต้นไม้สีสันสดใสเต็มไปหมดแล้ว ก็จะพลอยทำให้จิตใจของเราสงบสุข เบิกบานไปด้วย.</p>
      
      <h3>มุมนั่งเล่นในสวน </h3>
      <center><img src="https://scontent.fbkk10-1.fna.fbcdn.net/v/t34.0-12/25519770_2071450459751393_970485305_n.jpg?oh=aa561893a38354e04a254f770655226e&oe=5A3B98FB" width="40%" border="0" /></center><br>
      <p>นับเป็นอีกมุมที่สรรสร้างความผ่อนคลายได้เป็นอย่างดี ทั้งยังได้สูดอากาศบริสุทธิ์จากความเขียวขจีเข้าปอด
        โดยไม่ต้องเดินทางออกไปไกลบ้าน โดยเฉพาะอย่างยิ่งกับผู้ที่หลงใหลในการจัดสวนและหมู่แมกไม้นานาพรรณด้วยแล้ว 
        การมีมุมนั่งเล่นไว้ในสวน..</p>

        <h3>มุมของโต๊ะทำงาน</h3>
        <center><img src="https://scontent.fbkk10-1.fna.fbcdn.net/v/t35.0-12/s2048x2048/25577480_2071450469751392_2058244216_o.jpg?oh=58e68f99a733decab94ba57379caaa68&oe=5A3B31B8" width="40%" border="0" /></center><br>
        <p>คิดว่าหลายๆคนคงน่าจะอารมณืเดียวกันเวลาเช้าของทุกวัน หรือวันที่ต้องออกไปทำงาน 
            อารมณ์แบบมีโมเม้นที่ว่ายังไม่อยากไป เห็นโต๊ะทำงานเดิมๆเกิดอาการง่วง 
            ดังนั้น "การหาไอเดียที่รีเฟรชชีวิได้" ก็เป็นอะไรที่น่าทำเพราะเป็นเคล็ดลับเจ๋งๆ ให้ชีวิตเกิดแรงจูงใจที่อยากจะทำ
            ไอเดียการจัดโต๊ะทำงาน หรือ มุมทำงาน ให้น่านั่งยาวๆทำงานไปอารมณ์ดีไป เหมือนเป็นมุมหนึ่งของบ้านที่เราชอบจริงๆ
            ทำให้การทำงานตลอดทั้งวันมีความสุขกาย สบายใจ เป็นความสุขที่เราสร้างขึ้นเองได้.</p>

    </div>
    <div class="col-sm-2 sidenav">
      </div>
    </div>
  </div>
</div>
</body>
</html>