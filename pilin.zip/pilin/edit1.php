<?php 	
	$host ="localhost";
	$username ="root";
	$password ="";
	$objDB = "pilin";
	$connector = mysqli_connect($host, $username, $password, $objDB);
				mysqli_query($connector,"SET NAMES 'utf8' ");

	$No = $_POST["No"];
	$title = $_POST["title"];
	$detail = $_POST["detail"];
	$photo = $_FILES['image']['name'];
	
	
		$sql = "UPDATE data SET title ='$title', detail ='$detail' WHERE No = '$No' ";

		$query = mysqli_query($connector, $sql) or die ("Error in query: sql " . mysqli_error($connector));

	if($photo != "")
	{
		if(move_uploaded_file($_FILES["image"]["tmp_name"],"image/".$_FILES["image"]["name"]))
			{
				//*** Delete Old File ***//			
			@unlink("image/".$_POST["hdnOldFile"]);


			//*** Update New File ***//
			$sql = "UPDATE data ";
			$sql .=" SET photo = '".$_FILES["image"]["name"]."' WHERE No = '".$No."' ";
			$query= mysqli_query($connector, $sql);		

			echo "Copy/Upload Complete<br>";
			
		}
	}
	
  	if($query){

			echo "<script type='text/javascript'>";
			echo  "alert('แก้ไขข้อมูลเรียบร้อยแล้ว');";
			echo "window.location='show.php';";
			echo "</script>";
	  }

  	
mysqli_close($connector);
?>