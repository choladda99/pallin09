<?php 	
	$host ="localhost";
	$username ="root";
	$password ="";
	$objDB = "pilin";
	$connector = mysqli_connect($host, $username, $password, $objDB);
				mysqli_query($connector,"SET NAMES 'utf8' ");


	$title = $_POST["title"];
	$detail = $_POST["detail"];
	$photo = $_FILES['image']['name'];
	
	if(move_uploaded_file($_FILES["image"]["tmp_name"],"image/".$_FILES["image"]["name"]))
	   {	
			echo "Copy/Upload Complete<br>";

				
	//Insert to db	
			$sql = " INSERT INTO data (No,title,detail,photo) VALUES (NULL,'$title', '$detail', '$photo')";
			$result = mysqli_query($connector, $sql) or die ("Error in query: $sql " . mysqli_error($connector));
			 
				echo "<script type='text/javascript'>";
				echo  "alert('เพิ่มข้อมูลเรียบร้อยแล้ว');";
				echo "window.location='show.php';";
			echo "</script>";
			
			}	
		

mysqli_close($connector);
?>