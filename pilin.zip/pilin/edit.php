<!DOCTYPE html>
<html lang="en">
<head>
  <title>edit</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>แก้ไข</h2>
  <form action="edit1.php" method="post" enctype="multipart/form-data">

 <?php 
		$No = $_GET["No"];
		$host ="localhost";
		$username ="root";
		$password ="";
		$objDB = "pilin";
		$connector = mysqli_connect($host, $username, $password, $objDB);
				mysqli_query($connector,"SET NAMES 'utf8' ");
	
         $sql = "SELECT * FROM data WHERE No = $No";
         $result = mysqli_query($connector, $sql);
         	 
		while($row = mysqli_fetch_array($result))
			{
			?>  	
	<input type="hidden" name="No" value ="<?php echo $row["No"]; ?>">

    <div class="form-group">
      <label for="title">ชื่อต้นไม้</label>
      <input type="title" class="form-control" id="title" placeholder="กรอกชื่อต้นไม้" name="title" value="<?php echo $row["title"]; ?> ">
    </div>
	<div class="form-group">
	 <label for="detail">รายละเอียดต้นไม้</label>
	 <textarea class="form-control" rows="5" id="detail" name="detail" value="<?php echo $row["detail"]; ?> "></textarea>
	</div>
	<div class="form-group">
     <label>Photo:</label>
     <input type="file" name="image">
     </div>
   <input type="submit" name="submit" class="submit action-button" value="ยืนยัน" />
  </form>
</div>
<?php
}
?>

</body>
</html>
