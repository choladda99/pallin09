<!DOCTYPE html>
<html lang="en">
<head>
  <title>Green world tour</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #56d343;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="Index.php">หน้าแรก</a></li>
        <li><a href="4.php">เกร็ดความรู้</a></li>
        <li><a href="3.php">สินค้าสีเขียว</a></li>
        <li><a href="2.php">มุมสีเขียว</a></li>
		<li><a href="show.php">การจัดการข้อมูล</a></li>
      </ul>

    </div>
  </div>
</nav>
<!------------>
<?php
$host ="localhost";
				$username ="root";
				$password ="";
				$objDB = "pilin";
				$connector = mysqli_connect($host, $username, $password, $objDB);
							mysqli_query($connector,"SET NAMES 'utf8' ");
$strSQL = "SELECT * From data";
$objQuery = mysqli_query($connector,$strSQL) or die ("Error Query [".$strSQL."]");
$Num_Rows = mysqli_num_rows($objQuery);

$Per_Page = 5;   // Per Page

@$Page = $_GET["Page"];
if(@!$_GET["Page"])
{
	$Page=1;
}

$Prev_Page = $Page-1;
$Next_Page = $Page+1;

$Page_Start = (($Per_Page*$Page)-$Per_Page);
if($Num_Rows<=$Per_Page)
{
	$Num_Pages =1;
}
else if(($Num_Rows % $Per_Page)==0)
{
	$Num_Pages =($Num_Rows/$Per_Page) ;
}
else
{
	$Num_Pages =($Num_Rows/$Per_Page)+1;
	$Num_Pages = (int)$Num_Pages;
}

$strSQL .=" order  by No ASC LIMIT $Page_Start , $Per_Page";
$objQuery  = mysqli_query($connector,$strSQL);
?>
<!------------->
    <br><br><br><br>
    <center>


         <div style="background-color:white;">


          <table  align="center" width="900" border="1">

              <thead align="center" >
			  <tr align="center" >

				<th align="center">รูป</th>
				<th align="center">หัวข้อ</th>
				<th align="center">รายละเอียด</th>
				
				</tr>
              </thead>

              <?php

				$host ="localhost";
				$username ="root";
				$password ="";
				$objDB = "pilin";
				$connector = mysqli_connect($host, $username, $password, $objDB);
							mysqli_query($connector,"SET NAMES 'utf8' ");

				  ?>


           <?php
            while($objResult = mysqli_fetch_array($objQuery))
               {
              ?>

              <tbody>
                <tr>	  
				  <td align="center" ><img src="image/<?php echo $objResult["photo"];?>" style="width:350px;height:200px;"></td>   
                  <td align="center"><?php echo $objResult["title"];?></td>
                  <td align="center" ><?php echo $objResult["detail"];?></td>
			              
                </tr>
                <?php
                 }
                  ?>

              </tbody>
            </table>
            <br> <br> <br><br>
            <br> <br><br> <br>
            <br><br> <br> <br>
			</center>
<br>
<!------------>
<?php= $Num_Rows;?><?php=$Num_Pages;?> Page :
<?php
if($Prev_Page)
{
	echo " <a href='$_SERVER[SCRIPT_NAME]?Page=$Prev_Page'><< Back</a> ";
}

for($i=1; $i<=$Num_Pages; $i++){
	if($i != $Page)
	{
		echo "[ <a href='$_SERVER[SCRIPT_NAME]?Page=$i'>$i</a> ]";
	}
	else
	{
		echo "<b> $i </b>";
	}
}
if($Page!=$Num_Pages)
{
	echo " <a href ='$_SERVER[SCRIPT_NAME]?Page=$Next_Page'>Next>></a> ";
}
mysqli_close($connector);
?>

<!------------>     
             
     <div class="jumbotron text-center">
        <h3>Green World Tour</h3>
      <p>ที่อยู่ร้าน  ชื่อร้าน Green World Tour ซอย 4 บ้านหนองเดิ่น ต.หนองกอมเกาะ อ.เมือง จ.หนองคาย 43000</p><br> 
	  <p>E-mail : phailins@kkumail.com</p>
	  <p>Tel : 0862108764 </p>
   </div>    

  </body>
  </html>