<!DOCTYPE html>
<html lang="en">
<head>
  <title>Green world tour</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 700px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #56d343;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="Index.php">หน้าแรก</a></li>
        <li><a href="4.php">เกร็ดความรู้</a></li>
        <li><a href="3.php">สินค้าสีเขียว</a></li>
        <li><a href="2.php">มุมสีเขียว</a></li>
		<li><a href="show.php">การจัดการข้อมูล</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
    </div>
    <div class="col-sm-8 text-left"> 
      <h1>Welcome To Green World Tour</h1>
      <p>สิ่งแวดล้อม...คือทุกสิ่งทุกอย่างทั้งที่มีชีวิตและไม่มีชีวิต  ที่อยู่ล้อมรอบตัวเรา
          และส่งผลต่อเรา ทั้งที่เกิดขึ้นโดยธรรมชาติ เช่น แสงแดดจากดวงอาทิตย์ อากาศที่เราหายใจ
          ทะเล สายรุ้ง ป่าไม้ สัตว์และพืช และที่มนุษย์สร้างขึ้น เช้น อาคารสิ่งก่อสร้างๆต่าง ๆ.</p>
      <hr>
      <h3>เสน่ห์ของธรรมชาติ </h3>
      <p>เสน่ห์ของธรรมชาติ อยู่ที่ไม่มีใครสามารถสร้างขึ้นมาได้ 
            นอกจากธรรมชาติจะสร้างตัวของมันเอง บางสิ่งบางอย่าง 
            อาจใช้เวลาหลายร้อยล้านปี เพื่อรอให้เราได้เชยชมมันเพียง 
            ระยะสั้นๆเท่านั้น หมายถึงว่าเรามีชีวิตที่สั้นที่จะได้เชยชมกับ 
            ความงามของมันนั้นเอง มีแต่สิ่งมีชีวิตอย่างพวกเรานี้แหละที่ 
            คอยทำลายธรรมชาติอยู่ตลอดเวลา วันหนึ่งธรรมชาติก็จะกลืน 
            ชีวิตบนโลกนี้ไปทั้งหมด..</p>
    <center><img src="https://i.ytimg.com/vi/PjoF8CeDfEM/maxresdefault.jpg" width="40%" border="0" /></center>
    </div>
    <div class="col-sm-2 sidenav">
      </div>
    </div>
  </div>
</div>
</body>
</html>