<?php
$host ="localhost";
$username ="root";
$password ="";
$objDB = "pilin";
$connector = mysqli_connect($host, $username, $password, $objDB);
			mysqli_query($connector,"SET NAMES 'utf8' ");$strSQL = "DELETE FROM data ";
$strSQL = "DELETE FROM data ";
$strSQL .="WHERE No = '".$_GET["No"]."' ";
$objQuery = mysqli_query($connector,$strSQL);
if($objQuery)
{
    echo "Record Deleted.";
    echo "<script>";
    echo "window.location='show.php';";
    echo "</script>";
}
else
{
	echo "Error Delete [".$strSQL."]";
}

?>
